Koard Android SDK 1.0.7
See https://www.koard.com for documentation.
